#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo '9c627f2ac3a2a4e5360b7e62623f1846ac91a0f539698080628a8452b812634f  package-18971b1.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-18971b1-01
mkdir integrated-18971b1-source
tar -xf package-18971b1.tar -C integrated-18971b1-source
ln -s "$base/work/lean/.lake" integrated-18971b1-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd integrated-18971b1-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-18971b1-01/build.stdout" 2> "$base/integrated-18971b1-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-18971b1-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-18971b1-01/audit.stdout" 2> "$base/integrated-18971b1-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-18971b1-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-18971b1-01/audit.stdout" > "$base/integrated-18971b1-01/check.stdout" 2> "$base/integrated-18971b1-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-18971b1-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-18971b1-01/* > "$base/integrated-18971b1-01/output-sha256.txt"
