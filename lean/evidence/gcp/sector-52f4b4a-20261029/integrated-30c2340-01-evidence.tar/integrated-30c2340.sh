#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo 'f5938db36ae8e4d41f23db78c1916dee4e750e991f82d96c7131fe64b6da6082  package-30c2340.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-30c2340-01
mkdir integrated-30c2340-source
tar -xf package-30c2340.tar -C integrated-30c2340-source
ln -s "$base/source-2a560be/lean/.lake" integrated-30c2340-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-30c2340-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-30c2340-01/build.stdout" 2> "$base/integrated-30c2340-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-30c2340-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-30c2340-01/audit.stdout" 2> "$base/integrated-30c2340-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-30c2340-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-30c2340-01/audit.stdout" > "$base/integrated-30c2340-01/check.stdout" 2> "$base/integrated-30c2340-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-30c2340-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-30c2340-01/* > "$base/integrated-30c2340-01/output-sha256.txt"
