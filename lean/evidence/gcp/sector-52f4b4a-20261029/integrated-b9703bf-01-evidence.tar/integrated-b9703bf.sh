#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo '3b113099c10aa22ed678eb36cde0b61d32a9b1904dcd862cc4239ec57cb40f19  package-b9703bf.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-b9703bf-01
mkdir integrated-b9703bf-source
tar -xf package-b9703bf.tar -C integrated-b9703bf-source
ln -s "$base/source-2a560be/lean/.lake" integrated-b9703bf-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-b9703bf-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-b9703bf-01/build.stdout" 2> "$base/integrated-b9703bf-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-b9703bf-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-b9703bf-01/audit.stdout" 2> "$base/integrated-b9703bf-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-b9703bf-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-b9703bf-01/audit.stdout" > "$base/integrated-b9703bf-01/check.stdout" 2> "$base/integrated-b9703bf-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-b9703bf-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-b9703bf-01/* > "$base/integrated-b9703bf-01/output-sha256.txt"
