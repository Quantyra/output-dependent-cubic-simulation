set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo '4de8eafc1a9f63310eecb631ca028f482145d696ca71cc6a7631600b036e74c8  ColumnActionProbe-retry.lean' | sha256sum -c
! pgrep -x lean
! pgrep -x lake
mkdir column-retry-01
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd "$base/work/lean"
rc=0
timeout 900 lake env lean "$base/ColumnActionProbe-retry.lean" > "$base/column-retry-01/stdout" 2> "$base/column-retry-01/stderr" || rc=$?
echo "$rc" > "$base/column-retry-01/exit-code"
cat "$base/column-retry-01/exit-code" "$base/column-retry-01/stdout"
