#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo '38f9a1c9441c4b1c01d737d6d736c2a13cb90c682548cbd60c0061cc23a9f1a8  package-7188d99.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-7188d99-01
mkdir integrated-7188d99-source
tar -xf package-7188d99.tar -C integrated-7188d99-source
ln -s "$base/source-2a560be/lean/.lake" integrated-7188d99-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-7188d99-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-7188d99-01/build.stdout" 2> "$base/integrated-7188d99-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-7188d99-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-7188d99-01/audit.stdout" 2> "$base/integrated-7188d99-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-7188d99-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-7188d99-01/audit.stdout" > "$base/integrated-7188d99-01/check.stdout" 2> "$base/integrated-7188d99-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-7188d99-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-7188d99-01/* > "$base/integrated-7188d99-01/output-sha256.txt"
