#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo 'eded5f269bde4b8ba0f140fb261ca8fd983cdec15fcdb302f512f8862e004fd5  package-1c4e0c1.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-1c4e0c1-01
mkdir integrated-1c4e0c1-source
tar -xf package-1c4e0c1.tar -C integrated-1c4e0c1-source
ln -s "$base/work/lean/.lake" integrated-1c4e0c1-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd integrated-1c4e0c1-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-1c4e0c1-01/build.stdout" 2> "$base/integrated-1c4e0c1-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-1c4e0c1-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-1c4e0c1-01/audit.stdout" 2> "$base/integrated-1c4e0c1-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-1c4e0c1-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-1c4e0c1-01/audit.stdout" > "$base/integrated-1c4e0c1-01/check.stdout" 2> "$base/integrated-1c4e0c1-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-1c4e0c1-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-1c4e0c1-01/* > "$base/integrated-1c4e0c1-01/output-sha256.txt"
