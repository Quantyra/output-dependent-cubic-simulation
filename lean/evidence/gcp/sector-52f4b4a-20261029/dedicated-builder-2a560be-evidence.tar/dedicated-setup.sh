#!/usr/bin/env bash
set -euo pipefail
root=/home/dfredriksen_quantyra_org/sector-certification
cd "$root"
trap 'rc=$?; echo "$rc" > "$root/setup.exit-code"' EXIT
printf '%s  %s\n' 9c00cb40431349ab054b0bb0fbc1da51836ee9d414c761f45f8ee39e7b6111ca dedicated-source-2a560be.tar | sha256sum -c -
mkdir source-2a560be tools
tar -xf dedicated-source-2a560be.tar -C source-2a560be
sudo apt-get update
sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y git curl build-essential zstd jq time ca-certificates
curl -fL --retry 3 --connect-timeout 30 https://github.com/leanprover/lean4/releases/download/v4.30.0/lean-4.30.0-linux.tar.zst -o lean-4.30.0-linux.tar.zst
sha256sum lean-4.30.0-linux.tar.zst > lean-archive.sha256
tar --zstd -xf lean-4.30.0-linux.tar.zst -C tools
export PATH="$root/tools/lean-4.30.0-linux/bin:$PATH"
lean --version
cd "$root/source-2a560be/lean"
export MATHLIB_NO_CACHE_ON_UPDATE=1
lake update
cd ..
python3 tools/prepare_mathlib_complex_cache.py
cd lean
lake build
lake env lean Audit.lean > "$root/audit.stdout" 2> "$root/audit.stderr"
python3 ../tools/check_lean_audit.py "$root/audit.stdout"
echo setup-complete
