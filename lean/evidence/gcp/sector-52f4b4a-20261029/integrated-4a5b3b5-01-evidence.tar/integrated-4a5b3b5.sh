#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo '6392446bb489f713dbda6e009676e8c99a42027b3db4b70b23e6154d9a360b27  package-4a5b3b5.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-4a5b3b5-01
mkdir integrated-4a5b3b5-source
tar -xf package-4a5b3b5.tar -C integrated-4a5b3b5-source
ln -s "$base/source-2a560be/lean/.lake" integrated-4a5b3b5-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-4a5b3b5-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-4a5b3b5-01/build.stdout" 2> "$base/integrated-4a5b3b5-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-4a5b3b5-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-4a5b3b5-01/audit.stdout" 2> "$base/integrated-4a5b3b5-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-4a5b3b5-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-4a5b3b5-01/audit.stdout" > "$base/integrated-4a5b3b5-01/check.stdout" 2> "$base/integrated-4a5b3b5-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-4a5b3b5-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-4a5b3b5-01/* > "$base/integrated-4a5b3b5-01/output-sha256.txt"
