#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo '1c728da44a436a6c8c07737e1eaa77cd1b9eb13d3106ab219f505389388a1b33  package-e11fe68.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-e11fe68-01
mkdir integrated-e11fe68-source
tar -xf package-e11fe68.tar -C integrated-e11fe68-source
ln -s "$base/source-2a560be/lean/.lake" integrated-e11fe68-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-e11fe68-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-e11fe68-01/build.stdout" 2> "$base/integrated-e11fe68-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-e11fe68-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-e11fe68-01/audit.stdout" 2> "$base/integrated-e11fe68-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-e11fe68-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-e11fe68-01/audit.stdout" > "$base/integrated-e11fe68-01/check.stdout" 2> "$base/integrated-e11fe68-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-e11fe68-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-e11fe68-01/* > "$base/integrated-e11fe68-01/output-sha256.txt"
