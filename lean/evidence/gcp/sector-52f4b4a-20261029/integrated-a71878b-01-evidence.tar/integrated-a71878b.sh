#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo '912ecebf36cd1a6db4b4f60dee989bd333f05a08a2a4da0216dc9e8cf7fa9b5b  package-a71878b.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-a71878b-01
mkdir integrated-a71878b-source
tar -xf package-a71878b.tar -C integrated-a71878b-source
ln -s "$base/source-2a560be/lean/.lake" integrated-a71878b-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-a71878b-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-a71878b-01/build.stdout" 2> "$base/integrated-a71878b-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-a71878b-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-a71878b-01/audit.stdout" 2> "$base/integrated-a71878b-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-a71878b-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-a71878b-01/audit.stdout" > "$base/integrated-a71878b-01/check.stdout" 2> "$base/integrated-a71878b-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-a71878b-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-a71878b-01/* > "$base/integrated-a71878b-01/output-sha256.txt"
