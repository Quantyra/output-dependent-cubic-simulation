#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo '0a6abe93d32f188de54f568e8b1cb179e29f47126ab9204191cc0b8d5c688227  package-7eea6ef.tar' | sha256sum -c
! pgrep -x lean
! pgrep -x lake
mkdir integrated-7eea6ef-01
mkdir integrated-7eea6ef-source
tar -xf package-7eea6ef.tar -C integrated-7eea6ef-source
ln -s "$base/work/lean/.lake" integrated-7eea6ef-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd integrated-7eea6ef-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-7eea6ef-01/build.stdout" 2> "$base/integrated-7eea6ef-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-7eea6ef-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-7eea6ef-01/audit.stdout" 2> "$base/integrated-7eea6ef-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-7eea6ef-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-7eea6ef-01/audit.stdout" > "$base/integrated-7eea6ef-01/check.stdout" 2> "$base/integrated-7eea6ef-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-7eea6ef-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-7eea6ef-01/* > "$base/integrated-7eea6ef-01/output-sha256.txt"
