#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo 'f2d26e30d4210e8478c978cffea12088d320fab3c2294271f531e4c1a407bf66  package-f519c57.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-f519c57-01
mkdir integrated-f519c57-source
tar -xf package-f519c57.tar -C integrated-f519c57-source
ln -s "$base/source-2a560be/lean/.lake" integrated-f519c57-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-f519c57-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-f519c57-01/build.stdout" 2> "$base/integrated-f519c57-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-f519c57-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-f519c57-01/audit.stdout" 2> "$base/integrated-f519c57-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-f519c57-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-f519c57-01/audit.stdout" > "$base/integrated-f519c57-01/check.stdout" 2> "$base/integrated-f519c57-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-f519c57-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-f519c57-01/* > "$base/integrated-f519c57-01/output-sha256.txt"
