#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo '830b68836f336df03f9a61d1dc47af9fdbe70e7ec4f2fa11e2b7e7fe887cbd7c  package-de49edc.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-de49edc-01
mkdir integrated-de49edc-source
tar -xf package-de49edc.tar -C integrated-de49edc-source
ln -s "$base/work/lean/.lake" integrated-de49edc-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd integrated-de49edc-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-de49edc-01/build.stdout" 2> "$base/integrated-de49edc-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-de49edc-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-de49edc-01/audit.stdout" 2> "$base/integrated-de49edc-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-de49edc-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-de49edc-01/audit.stdout" > "$base/integrated-de49edc-01/check.stdout" 2> "$base/integrated-de49edc-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-de49edc-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-de49edc-01/* > "$base/integrated-de49edc-01/output-sha256.txt"
