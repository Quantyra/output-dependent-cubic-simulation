#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo 'a7d785823860b6e057337798fa59b46b23b06d0b7c74e1da7d819a5f84359024  package-c565f5a.tar' | sha256sum -c
! pgrep -x lean
! pgrep -x lake
mkdir integrated-c565f5a-01
mkdir integrated-c565f5a-source
tar -xf package-c565f5a.tar -C integrated-c565f5a-source
ln -s "$base/work/lean/.lake" integrated-c565f5a-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd integrated-c565f5a-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-c565f5a-01/build.stdout" 2> "$base/integrated-c565f5a-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-c565f5a-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-c565f5a-01/audit.stdout" 2> "$base/integrated-c565f5a-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-c565f5a-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-c565f5a-01/audit.stdout" > "$base/integrated-c565f5a-01/check.stdout" 2> "$base/integrated-c565f5a-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-c565f5a-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-c565f5a-01/* > "$base/integrated-c565f5a-01/output-sha256.txt"
