#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo 'b11c8001d7fa41164be9e5ce40f992a3efe11457e9456f27e35f4cf12dc63dd8  package-9c4f298.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-9c4f298-01
mkdir integrated-9c4f298-source
tar -xf package-9c4f298.tar -C integrated-9c4f298-source
ln -s "$base/work/lean/.lake" integrated-9c4f298-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd integrated-9c4f298-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-9c4f298-01/build.stdout" 2> "$base/integrated-9c4f298-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-9c4f298-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-9c4f298-01/audit.stdout" 2> "$base/integrated-9c4f298-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-9c4f298-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-9c4f298-01/audit.stdout" > "$base/integrated-9c4f298-01/check.stdout" 2> "$base/integrated-9c4f298-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-9c4f298-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-9c4f298-01/* > "$base/integrated-9c4f298-01/output-sha256.txt"
