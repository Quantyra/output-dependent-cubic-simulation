#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo '543b7ae9916b1a983b1ac0f0a8f8225d7a0c2466b8214759313f9e54d1aa404a  package-edb49d9.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-edb49d9-01
mkdir integrated-edb49d9-source
tar -xf package-edb49d9.tar -C integrated-edb49d9-source
ln -s "$base/source-2a560be/lean/.lake" integrated-edb49d9-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-edb49d9-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-edb49d9-01/build.stdout" 2> "$base/integrated-edb49d9-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-edb49d9-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-edb49d9-01/audit.stdout" 2> "$base/integrated-edb49d9-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-edb49d9-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-edb49d9-01/audit.stdout" > "$base/integrated-edb49d9-01/check.stdout" 2> "$base/integrated-edb49d9-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-edb49d9-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-edb49d9-01/* > "$base/integrated-edb49d9-01/output-sha256.txt"
