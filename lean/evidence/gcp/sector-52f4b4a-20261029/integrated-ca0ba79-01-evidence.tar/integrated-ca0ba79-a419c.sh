#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo '464920959320a64a91ca27401fc38439f75023962da65bc46b1abaf5a33be59f  package-ca0ba79.tar' | sha256sum -c
! pgrep -x lean
! pgrep -x lake
mkdir integrated-ca0ba79-01
mkdir integrated-ca0ba79-source
tar -xf package-ca0ba79.tar -C integrated-ca0ba79-source
ln -s "$base/work/lean/.lake" integrated-ca0ba79-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd integrated-ca0ba79-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-ca0ba79-01/build.stdout" 2> "$base/integrated-ca0ba79-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-ca0ba79-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-ca0ba79-01/audit.stdout" 2> "$base/integrated-ca0ba79-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-ca0ba79-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-ca0ba79-01/audit.stdout" > "$base/integrated-ca0ba79-01/check.stdout" 2> "$base/integrated-ca0ba79-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-ca0ba79-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-ca0ba79-01/* > "$base/integrated-ca0ba79-01/output-sha256.txt"
