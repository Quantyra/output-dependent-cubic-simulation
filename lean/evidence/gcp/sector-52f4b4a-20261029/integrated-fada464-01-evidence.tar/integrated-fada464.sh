#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo 'a2d443a6ff024d7ea24637cbceebf10fd35ef890a46594d8817f82162ab287d4  package-fada464.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-fada464-01
mkdir integrated-fada464-source
tar -xf package-fada464.tar -C integrated-fada464-source
ln -s "$base/source-2a560be/lean/.lake" integrated-fada464-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-fada464-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-fada464-01/build.stdout" 2> "$base/integrated-fada464-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-fada464-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-fada464-01/audit.stdout" 2> "$base/integrated-fada464-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-fada464-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-fada464-01/audit.stdout" > "$base/integrated-fada464-01/check.stdout" 2> "$base/integrated-fada464-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-fada464-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-fada464-01/* > "$base/integrated-fada464-01/output-sha256.txt"
