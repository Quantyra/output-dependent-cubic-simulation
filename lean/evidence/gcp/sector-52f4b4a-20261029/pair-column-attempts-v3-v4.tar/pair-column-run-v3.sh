set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo '2ff468986cbda780c03fdf59882f96e6bdd90009b8cfa12d5dfe97550afa4b01  PairColumnBridgeProbe-v3.lean' | sha256sum -c
! pgrep -x lean
! pgrep -x lake
mkdir pair-column-bridge-03
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd "$base/integrated-7eea6ef-source/lean"
rc=0
timeout 900 lake env lean "$base/PairColumnBridgeProbe-v3.lean" > "$base/pair-column-bridge-03/stdout" 2> "$base/pair-column-bridge-03/stderr" || rc=$?
echo "$rc" > "$base/pair-column-bridge-03/exit-code"
cat "$base/pair-column-bridge-03/exit-code" "$base/pair-column-bridge-03/stdout"
