set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo 'a9258dbb9714c920b6fa9be0f86927ef0158d469f49acf30c520c327b66de596  PairColumnBridgeProbe-v4.lean' | sha256sum -c
! pgrep -x lean
! pgrep -x lake
mkdir pair-column-bridge-04
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd "$base/integrated-7eea6ef-source/lean"
rc=0
timeout 900 lake env lean "$base/PairColumnBridgeProbe-v4.lean" > "$base/pair-column-bridge-04/stdout" 2> "$base/pair-column-bridge-04/stderr" || rc=$?
echo "$rc" > "$base/pair-column-bridge-04/exit-code"
cat "$base/pair-column-bridge-04/exit-code" "$base/pair-column-bridge-04/stdout"
