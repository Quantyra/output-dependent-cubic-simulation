#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo 'bff3ab9813bf939a71a4141d97941640e6c83b7f92e73ce0669228467ac1fa07  package-e4b64c3.tar' | sha256sum -c
! pgrep -x lean
! pgrep -x lake
mkdir integrated-e4b64c3-01
mkdir integrated-e4b64c3-source
tar -xf package-e4b64c3.tar -C integrated-e4b64c3-source
ln -s "$base/work/lean/.lake" integrated-e4b64c3-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd integrated-e4b64c3-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-e4b64c3-01/build.stdout" 2> "$base/integrated-e4b64c3-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-e4b64c3-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-e4b64c3-01/audit.stdout" 2> "$base/integrated-e4b64c3-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-e4b64c3-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-e4b64c3-01/audit.stdout" > "$base/integrated-e4b64c3-01/check.stdout" 2> "$base/integrated-e4b64c3-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-e4b64c3-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-e4b64c3-01/* > "$base/integrated-e4b64c3-01/output-sha256.txt"
