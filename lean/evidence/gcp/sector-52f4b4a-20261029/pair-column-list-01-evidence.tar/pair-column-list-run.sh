set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo '660092ea4ebe1224821be153c1616a1e565d1e924caba8d9b74810c50e0cf4a1  PairColumnListProbe.lean' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir pair-column-list-01
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd "$base/integrated-9c4f298-source/lean"
rc=0
timeout 900 lake env lean "$base/PairColumnListProbe.lean" > "$base/pair-column-list-01/stdout" 2> "$base/pair-column-list-01/stderr" || rc=$?
echo "$rc" > "$base/pair-column-list-01/exit-code"
cat "$base/pair-column-list-01/exit-code" "$base/pair-column-list-01/stdout"
