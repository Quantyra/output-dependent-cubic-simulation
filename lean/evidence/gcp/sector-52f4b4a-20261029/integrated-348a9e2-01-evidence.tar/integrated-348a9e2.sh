#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo '73bfbe764bbc10f4ade85de5302d88ddca9bc6a668bf0540a225f7769b0277fd  package-348a9e2.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-348a9e2-01
mkdir integrated-348a9e2-source
tar -xf package-348a9e2.tar -C integrated-348a9e2-source
ln -s "$base/work/lean/.lake" integrated-348a9e2-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd integrated-348a9e2-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-348a9e2-01/build.stdout" 2> "$base/integrated-348a9e2-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-348a9e2-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-348a9e2-01/audit.stdout" 2> "$base/integrated-348a9e2-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-348a9e2-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-348a9e2-01/audit.stdout" > "$base/integrated-348a9e2-01/check.stdout" 2> "$base/integrated-348a9e2-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-348a9e2-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-348a9e2-01/* > "$base/integrated-348a9e2-01/output-sha256.txt"
