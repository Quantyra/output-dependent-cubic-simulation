set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo '00a99876471bf75e0ea00a06fb6b928094dab3a9d69003e8c0767ea3456bda07  PairColumnBridgeProbe-v6.lean' | sha256sum -c
! pgrep -x lean
! pgrep -x lake
mkdir pair-column-bridge-06
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd "$base/integrated-7eea6ef-source/lean"
rc=0
timeout 900 lake env lean "$base/PairColumnBridgeProbe-v6.lean" > "$base/pair-column-bridge-06/stdout" 2> "$base/pair-column-bridge-06/stderr" || rc=$?
echo "$rc" > "$base/pair-column-bridge-06/exit-code"
cat "$base/pair-column-bridge-06/exit-code" "$base/pair-column-bridge-06/stdout"
