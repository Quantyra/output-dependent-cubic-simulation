set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo 'a784d6a2ba5602f3384479fa565914894c3481133f1a4c4b4ce38a6d88f7a4f3  PairColumnBridgeProbe-v5.lean' | sha256sum -c
! pgrep -x lean
! pgrep -x lake
mkdir pair-column-bridge-05
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd "$base/integrated-7eea6ef-source/lean"
rc=0
timeout 900 lake env lean "$base/PairColumnBridgeProbe-v5.lean" > "$base/pair-column-bridge-05/stdout" 2> "$base/pair-column-bridge-05/stderr" || rc=$?
echo "$rc" > "$base/pair-column-bridge-05/exit-code"
cat "$base/pair-column-bridge-05/exit-code" "$base/pair-column-bridge-05/stdout"
