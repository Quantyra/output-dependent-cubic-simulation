import SectorSimulation.CanonicalVectorWalsh
import SectorSimulation.BinaryShift
namespace SectorSimulation

theorem binaryShift_basis_perm {n : Nat} (j : BinaryVector n) :
    ((binaryBasis n).map (binaryShift j)).Perm (binaryBasis n) := by
  have hinj : Function.Injective (binaryShift j) := by
    intro a b h
    have h' := congrArg (binaryShift j) h
    simpa only [binaryShift_involutive] using h'
  have hn : ((binaryBasis n).map (binaryShift j)).Nodup := by
    exact List.Pairwise.map _ (fun _ _ h h' => h (hinj h')) (binaryBasis_nodup n)
  apply List.perm_iff_count.mpr
  intro x
  rw [hn.count, (binaryBasis_nodup n).count]
  have hm : x ∈ (binaryBasis n).map (binaryShift j) :=
    List.mem_map.mpr ⟨binaryShift j x, binaryBasis_complete _, binaryShift_involutive j x⟩
  simp [hm, binaryBasis_complete]

theorem integerWalshSign_xor (a b : Bool) :
    integerWalshSign (Bool.xor a b) = integerWalshSign a * integerWalshSign b := by
  cases a <;> cases b <;> rfl

theorem integerWalshSign_not (a : Bool) : integerWalshSign (!a) = -integerWalshSign a := by
  cases a <;> rfl

theorem integerSum_map_neg {α : Type} (xs : List α) (f : α → Int) :
    (xs.map (fun x => -f x)).sum = -(xs.map f).sum := by
  induction xs with
  | nil => rfl
  | cons a rest ih => simp [ih, Int.neg_add]

theorem shiftedSignSum_cancel {n : Nat} (f : BinaryVector n → Bool) (j : BinaryVector n)
    (hflip : ∀ x, f (binaryShift j x) = !f x) :
    ((binaryBasis n).map (fun x => integerWalshSign (f x))).sum = 0 := by
  let g := fun x : BinaryVector n => integerWalshSign (f x)
  have hp := integerSum_perm _ _ (binaryShift_basis_perm j).symm g
  have he : ((binaryBasis n).map g).sum = -((binaryBasis n).map g).sum := by
    simpa [g, List.map_map, Function.comp_def, hflip, integerWalshSign_not, integerSum_map_neg] using hp
  dsimp [g] at he
  omega

end SectorSimulation
#print axioms SectorSimulation.binaryShift_basis_perm
#print axioms SectorSimulation.integerWalshSign_xor
#print axioms SectorSimulation.integerWalshSign_not
#print axioms SectorSimulation.integerSum_map_neg
#print axioms SectorSimulation.shiftedSignSum_cancel
