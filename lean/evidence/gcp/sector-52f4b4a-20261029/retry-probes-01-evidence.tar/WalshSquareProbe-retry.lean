import SectorSimulation.CanonicalVectorWalsh
import SectorSimulation.BinaryShift
namespace SectorSimulation

theorem binaryShift_basis_perm {n : Nat} (j : BinaryVector n) :
    ((binaryBasis n).map (binaryShift j)).Perm (binaryBasis n) := by
  have hinj : Function.Injective (binaryShift j) := by
    intro a b h
    have h' := congrArg (binaryShift j) h
    simpa only [binaryShift_involutive] using h'
  have hn : ((binaryBasis n).map (binaryShift j)).Nodup := by
    exact List.Pairwise.map _ (fun _ _ h h' => h (hinj h')) (binaryBasis_nodup n)
  apply List.perm_iff_count.mpr
  intro x
  rw [hn.count, (binaryBasis_nodup n).count]
  have hm : x ∈ (binaryBasis n).map (binaryShift j) :=
    List.mem_map.mpr ⟨binaryShift j x, binaryBasis_complete _, binaryShift_involutive j x⟩
  simp [hm, binaryBasis_complete]

theorem integerWalshSign_xor (a b : Bool) :
    integerWalshSign (Bool.xor a b) = integerWalshSign a * integerWalshSign b := by
  cases a <;> cases b <;> rfl

theorem integerWalshSign_not (a : Bool) : integerWalshSign (!a) = -integerWalshSign a := by
  cases a <;> rfl

theorem integerSum_map_neg {α : Type} (xs : List α) (f : α → Int) :
    (xs.map (fun x => -f x)).sum = -(xs.map f).sum := by
  induction xs with
  | nil => rfl
  | cons a rest ih => simp [ih, Int.neg_add]

theorem shiftedSignSum_cancel {n : Nat} (f : BinaryVector n → Bool) (j : BinaryVector n)
    (hflip : ∀ x, f (binaryShift j x) = !f x) :
    ((binaryBasis n).map (fun x => integerWalshSign (f x))).sum = 0 := by
  let g := fun x : BinaryVector n => integerWalshSign (f x)
  have hp := integerSum_perm _ _ (binaryShift_basis_perm j).symm g
  have he : ((binaryBasis n).map g).sum = -((binaryBasis n).map g).sum := by
    simpa [g, List.map_map, Function.comp_def, hflip, integerWalshSign_not, integerSum_map_neg] using hp
  dsimp [g] at he
  omega


theorem integerSum_mul_right {α : Type} (xs : List α) (f : α → Int) (v : Int) :
    (xs.map f).sum * v = (xs.map (fun x => f x * v)).sum := by
  induction xs with
  | nil => simp
  | cons x rest ih => simp [Int.add_mul, ih]

theorem integerMul_sum_left {α : Type} (v : Int) (xs : List α) (f : α → Int) :
    v * (xs.map f).sum = (xs.map (fun x => v * f x)).sum := by
  induction xs with
  | nil => simp
  | cons x rest ih => simp [Int.mul_add, ih]

theorem integerSquare_doubleSum {α : Type} (xs : List α) (f : α → Int) :
    (xs.map f).sum * (xs.map f).sum =
      (xs.map (fun x => (xs.map (fun y => f x * f y)).sum)).sum := by
  rw [integerSum_mul_right]
  apply congrArg List.sum
  apply List.map_congr_left
  intro x hx
  exact integerMul_sum_left (f x) xs f

theorem binaryShift_doubleSum {n : Nat} (f : BinaryVector n → BinaryVector n → Int) :
    ((binaryBasis n).map (fun x => ((binaryBasis n).map (f x)).sum)).sum =
      ((binaryBasis n).map (fun x => ((binaryBasis n).map (fun u => f x (binaryShift x u))).sum)).sum := by
  apply congrArg List.sum
  apply List.map_congr_left
  intro x hx
  have h := integerSum_perm _ _ (binaryShift_basis_perm x).symm (f x)
  simpa [List.map_map, Function.comp_def] using h

theorem shiftedSquare_expansion {n : Nat} (f : BinaryVector n → Int) :
    ((binaryBasis n).map f).sum * ((binaryBasis n).map f).sum =
      ((binaryBasis n).map (fun x => ((binaryBasis n).map (fun u => f x * f (binaryShift x u))).sum)).sum := by
  rw [integerSquare_doubleSum]
  exact binaryShift_doubleSum (fun x y => f x * f y)

end SectorSimulation
#print axioms SectorSimulation.integerSquare_doubleSum
#print axioms SectorSimulation.binaryShift_doubleSum
#print axioms SectorSimulation.shiftedSquare_expansion
