#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo '2f26f3bb33640373107530bef5aec51f77effbd7ee4cfeabce3519ca8677b428  package-f92233a.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-f92233a-01
mkdir integrated-f92233a-source
tar -xf package-f92233a.tar -C integrated-f92233a-source
ln -s "$base/source-2a560be/lean/.lake" integrated-f92233a-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-f92233a-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-f92233a-01/build.stdout" 2> "$base/integrated-f92233a-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-f92233a-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-f92233a-01/audit.stdout" 2> "$base/integrated-f92233a-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-f92233a-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-f92233a-01/audit.stdout" > "$base/integrated-f92233a-01/check.stdout" 2> "$base/integrated-f92233a-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-f92233a-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-f92233a-01/* > "$base/integrated-f92233a-01/output-sha256.txt"
