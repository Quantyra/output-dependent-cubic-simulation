#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo 'af820ea2c6e1083376010f36da5ed39f475f28e50e33ebc4e473b17e1eaf3f2a  package-f524b9e.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-f524b9e-01
mkdir integrated-f524b9e-source
tar -xf package-f524b9e.tar -C integrated-f524b9e-source
ln -s "$base/source-2a560be/lean/.lake" integrated-f524b9e-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-f524b9e-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-f524b9e-01/build.stdout" 2> "$base/integrated-f524b9e-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-f524b9e-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-f524b9e-01/audit.stdout" 2> "$base/integrated-f524b9e-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-f524b9e-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-f524b9e-01/audit.stdout" > "$base/integrated-f524b9e-01/check.stdout" 2> "$base/integrated-f524b9e-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-f524b9e-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-f524b9e-01/* > "$base/integrated-f524b9e-01/output-sha256.txt"
