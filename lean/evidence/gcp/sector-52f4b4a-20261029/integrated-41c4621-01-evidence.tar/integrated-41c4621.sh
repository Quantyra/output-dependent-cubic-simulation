#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo '84619022b287043de0fd1e94fd8defb75759f83b6e6e134e2f36423f6bf55926  package-41c4621.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-41c4621-01
mkdir integrated-41c4621-source
tar -xf package-41c4621.tar -C integrated-41c4621-source
ln -s "$base/work/lean/.lake" integrated-41c4621-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd integrated-41c4621-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-41c4621-01/build.stdout" 2> "$base/integrated-41c4621-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-41c4621-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-41c4621-01/audit.stdout" 2> "$base/integrated-41c4621-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-41c4621-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-41c4621-01/audit.stdout" > "$base/integrated-41c4621-01/check.stdout" 2> "$base/integrated-41c4621-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-41c4621-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-41c4621-01/* > "$base/integrated-41c4621-01/output-sha256.txt"
