#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo 'de917092bc8d0e005b479270a073abdb178ea8581083cc540ff008c52d6c0997  package-2b90b82.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-2b90b82-01
mkdir integrated-2b90b82-source
tar -xf package-2b90b82.tar -C integrated-2b90b82-source
ln -s "$base/source-2a560be/lean/.lake" integrated-2b90b82-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-2b90b82-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-2b90b82-01/build.stdout" 2> "$base/integrated-2b90b82-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-2b90b82-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-2b90b82-01/audit.stdout" 2> "$base/integrated-2b90b82-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-2b90b82-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-2b90b82-01/audit.stdout" > "$base/integrated-2b90b82-01/check.stdout" 2> "$base/integrated-2b90b82-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-2b90b82-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-2b90b82-01/* > "$base/integrated-2b90b82-01/output-sha256.txt"
