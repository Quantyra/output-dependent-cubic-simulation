#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo '12db354bcfd7574cd40b9a505cb87e4f62447e9f9b8d49780e222073256b689c  package-6bd2a14.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-6bd2a14-01
mkdir integrated-6bd2a14-source
tar -xf package-6bd2a14.tar -C integrated-6bd2a14-source
ln -s "$base/source-2a560be/lean/.lake" integrated-6bd2a14-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-6bd2a14-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-6bd2a14-01/build.stdout" 2> "$base/integrated-6bd2a14-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-6bd2a14-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-6bd2a14-01/audit.stdout" 2> "$base/integrated-6bd2a14-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-6bd2a14-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-6bd2a14-01/audit.stdout" > "$base/integrated-6bd2a14-01/check.stdout" 2> "$base/integrated-6bd2a14-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-6bd2a14-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-6bd2a14-01/* > "$base/integrated-6bd2a14-01/output-sha256.txt"
