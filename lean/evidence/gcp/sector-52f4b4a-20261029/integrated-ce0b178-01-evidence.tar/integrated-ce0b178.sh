#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo '6b911e90a7770969581e5bcb566be404ad429b1fb4b5ffc2644b1342793044ff  package-ce0b178.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-ce0b178-01
mkdir integrated-ce0b178-source
tar -xf package-ce0b178.tar -C integrated-ce0b178-source
ln -s "$base/source-2a560be/lean/.lake" integrated-ce0b178-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-ce0b178-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-ce0b178-01/build.stdout" 2> "$base/integrated-ce0b178-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-ce0b178-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-ce0b178-01/audit.stdout" 2> "$base/integrated-ce0b178-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-ce0b178-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-ce0b178-01/audit.stdout" > "$base/integrated-ce0b178-01/check.stdout" 2> "$base/integrated-ce0b178-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-ce0b178-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-ce0b178-01/* > "$base/integrated-ce0b178-01/output-sha256.txt"
