#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo 'f65e0d81e7585559b40dfd383c709913db1e1eaaabd5c45747c718598ef91493  package-08b5a9a.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-08b5a9a-01
mkdir integrated-08b5a9a-source
tar -xf package-08b5a9a.tar -C integrated-08b5a9a-source
ln -s "$base/source-2a560be/lean/.lake" integrated-08b5a9a-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-08b5a9a-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-08b5a9a-01/build.stdout" 2> "$base/integrated-08b5a9a-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-08b5a9a-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-08b5a9a-01/audit.stdout" 2> "$base/integrated-08b5a9a-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-08b5a9a-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-08b5a9a-01/audit.stdout" > "$base/integrated-08b5a9a-01/check.stdout" 2> "$base/integrated-08b5a9a-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-08b5a9a-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-08b5a9a-01/* > "$base/integrated-08b5a9a-01/output-sha256.txt"
