import SectorSimulation.PairCross
namespace SectorSimulation

theorem matrixApply_coordinateUnit {n : Nat} (J : BinaryMatrix n) (i : Fin n) :
    matrixApply J (coordinateUnit i) = matrixColumn J i := by
  funext row
  simp only [matrixApply, coordinateUnit, matrixColumn, xorFoldl_as_sum, Bool.false_xor]
  have h : (fun j => J row j && decide (j = i)) =
      (fun j => decide (j = i) && J row j) := by
    funext j; exact Bool.and_comm _ _
  rw [h, booleanListSum_singleton _ i _ (List.nodup_finRange n)]
  simp

theorem sourcePolar_units_are_columns {n : Nat} (p : PhaseANF n) (J : BinaryMatrix n)
    (i j : Fin n) :
    phasePolarFunction (fun x => evalPhase p (matrixApply J x)) (coordinateUnit i) (coordinateUnit j) =
      phasePolar p (matrixColumn J i) (matrixColumn J j) := by
  rw [sourcePolar_matrixChange, matrixApply_coordinateUnit, matrixApply_coordinateUnit]
#print axioms matrixApply_coordinateUnit
#print axioms sourcePolar_units_are_columns
end SectorSimulation
