#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo 'fda1fedf2b673214a29d2d26409322dbed6f22806a546fa3195e45d40d041c9f  package-55be24a.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-55be24a-01
mkdir integrated-55be24a-source
tar -xf package-55be24a.tar -C integrated-55be24a-source
ln -s "$base/source-2a560be/lean/.lake" integrated-55be24a-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-55be24a-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-55be24a-01/build.stdout" 2> "$base/integrated-55be24a-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-55be24a-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-55be24a-01/audit.stdout" 2> "$base/integrated-55be24a-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-55be24a-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-55be24a-01/audit.stdout" > "$base/integrated-55be24a-01/check.stdout" 2> "$base/integrated-55be24a-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-55be24a-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-55be24a-01/* > "$base/integrated-55be24a-01/output-sha256.txt"
