#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo '54ad8924a421b4cece07a63dcdbfe30f008863ea545bb3b374e4c86f39a28fc2  package-be6acc4.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-be6acc4-01
mkdir integrated-be6acc4-source
tar -xf package-be6acc4.tar -C integrated-be6acc4-source
ln -s "$base/source-2a560be/lean/.lake" integrated-be6acc4-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-be6acc4-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-be6acc4-01/build.stdout" 2> "$base/integrated-be6acc4-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-be6acc4-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-be6acc4-01/audit.stdout" 2> "$base/integrated-be6acc4-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-be6acc4-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-be6acc4-01/audit.stdout" > "$base/integrated-be6acc4-01/check.stdout" 2> "$base/integrated-be6acc4-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-be6acc4-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-be6acc4-01/* > "$base/integrated-be6acc4-01/output-sha256.txt"
