set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo '487477affb6b72e5234e6dd0c1be06006806d958f14a73c8677e7c67ffe3071e  PairColumnInvariantProbe.lean' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir pair-column-invariant-01
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd "$base/integrated-de49edc-source/lean"
rc=0
timeout 900 lake env lean "$base/PairColumnInvariantProbe.lean" > "$base/pair-column-invariant-01/stdout" 2> "$base/pair-column-invariant-01/stderr" || rc=$?
echo "$rc" > "$base/pair-column-invariant-01/exit-code"
cat "$base/pair-column-invariant-01/exit-code" "$base/pair-column-invariant-01/stdout"
