import SectorSimulation.PolarCost
import SectorSimulation.QuadraticSourcePolar
namespace SectorSimulation

theorem sourceQuadratic_normal_certificate {n : Nat} (p : PhaseANF n)
    (fuel : Nat) (indices : List (Fin n)) (J : BinaryMatrix n)
    (hdegree : phaseWithinDegree 2 p = true)
    (hn : indices.Nodup) (hbound : indices.length <= fuel) :
    let result := polarEliminate (phasePolar p) fuel indices J
    runColumnAdds result.2.1 J = result.1 ∧
    runColumnAdds result.2.1.reverse result.1 = J ∧
    (∀ p ∈ result.2.2, p.1 ∈ indices ∧ p.2 ∈ indices) ∧
    (∀ p ∈ result.2.2, p.1 ≠ p.2) ∧
    result.2.2.Pairwise pairDisjoint ∧
    (∀ p ∈ result.2.2, (phasePolar p) (matrixColumn result.1 p.1) (matrixColumn result.1 p.2) = true) ∧
    result.2.2.Pairwise (pairOrthogonal (phasePolar p) result.1) ∧
    (∀ u ∈ unpairedIndices indices result.2.2, ∀ v ∈ unpairedIndices indices result.2.2,
      (phasePolar p) (matrixColumn result.1 u) (matrixColumn result.1 v) = false) ∧
    (∀ t ∈ unpairedIndices indices result.2.2, ∀ p ∈ result.2.2,
      (phasePolar p) (matrixColumn result.1 t) (matrixColumn result.1 p.1) = false ∧
      (phasePolar p) (matrixColumn result.1 t) (matrixColumn result.1 p.2) = false) := by
  obtain ?ts, hts, heval, hpolar, halt, hadd, hright? := sourceQuadratic_hasPolar p hdegree
  have ha : ? a b z, phasePolar p (binaryShift a b) z = Bool.xor (phasePolar p a z) (phasePolar p b z) := by
    intro a b z; simp only [hpolar, hadd]
  have hz : ? z, phasePolar p (fun _ => false) z = false := by
    intro z
    simp [phasePolar, binaryShift, Bool.xor_assoc]
  have hl : ? x, phasePolar p x x = false := by
    intro x; rw [hpolar]; exact halt x
  have hs : ? x y, phasePolar p x y = phasePolar p y x := by
    intro x y; simp only [hpolar, termsPolar_symmetric]
  exact polarEliminate_normal_certificate (phasePolar p) fuel indices J ha hz hl hs hn hbound
#print axioms sourceQuadratic_normal_certificate
end SectorSimulation
