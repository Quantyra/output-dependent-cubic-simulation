#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo '1f585c2e46d6bd1032bece1029a888a890295a9bd50ec142fa49d81d596af7a2  package-0f77c33.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-0f77c33-01
mkdir integrated-0f77c33-source
tar -xf package-0f77c33.tar -C integrated-0f77c33-source
ln -s "$base/source-2a560be/lean/.lake" integrated-0f77c33-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-0f77c33-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-0f77c33-01/build.stdout" 2> "$base/integrated-0f77c33-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-0f77c33-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-0f77c33-01/audit.stdout" 2> "$base/integrated-0f77c33-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-0f77c33-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-0f77c33-01/audit.stdout" > "$base/integrated-0f77c33-01/check.stdout" 2> "$base/integrated-0f77c33-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-0f77c33-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-0f77c33-01/* > "$base/integrated-0f77c33-01/output-sha256.txt"
