#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo '9b9ebd9e549c4da2f6e001d50fcdc8d6c01aa7c562a7eafa8093206163665047  package-f2bd73c.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-f2bd73c-01
mkdir integrated-f2bd73c-source
tar -xf package-f2bd73c.tar -C integrated-f2bd73c-source
ln -s "$base/work/lean/.lake" integrated-f2bd73c-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd integrated-f2bd73c-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-f2bd73c-01/build.stdout" 2> "$base/integrated-f2bd73c-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-f2bd73c-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-f2bd73c-01/audit.stdout" 2> "$base/integrated-f2bd73c-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-f2bd73c-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-f2bd73c-01/audit.stdout" > "$base/integrated-f2bd73c-01/check.stdout" 2> "$base/integrated-f2bd73c-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-f2bd73c-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-f2bd73c-01/* > "$base/integrated-f2bd73c-01/output-sha256.txt"
