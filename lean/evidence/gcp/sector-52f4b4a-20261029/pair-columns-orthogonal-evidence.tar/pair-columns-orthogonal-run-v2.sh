set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo 'e9a9c7a76181c2b00c3d6bc96a0eef2a958d1113909c09526f0e36865d932cb8  PairColumnsOrthogonalProbe-v2.lean' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir pair-columns-orthogonal-02
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd "$base/integrated-f2bd73c-source/lean"
rc=0
timeout 900 lake env lean "$base/PairColumnsOrthogonalProbe-v2.lean" > "$base/pair-columns-orthogonal-02/stdout" 2> "$base/pair-columns-orthogonal-02/stderr" || rc=$?
echo "$rc" > "$base/pair-columns-orthogonal-02/exit-code"
cat "$base/pair-columns-orthogonal-02/exit-code" "$base/pair-columns-orthogonal-02/stdout"
