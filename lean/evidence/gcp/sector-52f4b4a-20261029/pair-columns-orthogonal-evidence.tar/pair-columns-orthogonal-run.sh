set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo '5496501b85ac2cbf261a7e7b5f726eff0ee082685ad219aac15260bd3bf7cb75  PairColumnsOrthogonalProbe.lean' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir pair-columns-orthogonal-01
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd "$base/integrated-f2bd73c-source/lean"
rc=0
timeout 900 lake env lean "$base/PairColumnsOrthogonalProbe.lean" > "$base/pair-columns-orthogonal-01/stdout" 2> "$base/pair-columns-orthogonal-01/stderr" || rc=$?
echo "$rc" > "$base/pair-columns-orthogonal-01/exit-code"
cat "$base/pair-columns-orthogonal-01/exit-code" "$base/pair-columns-orthogonal-01/stdout"
