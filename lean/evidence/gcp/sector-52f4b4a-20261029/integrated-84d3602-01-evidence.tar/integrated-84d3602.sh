#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo '3b260be6cd73cfee0bb6ef399e0daa5b1c65e833a432723e81b1afcf607e6501  package-84d3602.tar' | sha256sum -c
! pgrep -x lean
! pgrep -x lake
mkdir integrated-84d3602-01
mkdir integrated-84d3602-source
tar -xf package-84d3602.tar -C integrated-84d3602-source
ln -s "$base/work/lean/.lake" integrated-84d3602-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd integrated-84d3602-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-84d3602-01/build.stdout" 2> "$base/integrated-84d3602-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-84d3602-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-84d3602-01/audit.stdout" 2> "$base/integrated-84d3602-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-84d3602-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-84d3602-01/audit.stdout" > "$base/integrated-84d3602-01/check.stdout" 2> "$base/integrated-84d3602-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-84d3602-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-84d3602-01/* > "$base/integrated-84d3602-01/output-sha256.txt"
