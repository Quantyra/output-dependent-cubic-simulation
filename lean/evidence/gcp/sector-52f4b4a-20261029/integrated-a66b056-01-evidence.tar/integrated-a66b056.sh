#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo '113e27faa0abaefe313f7f411411af0f5e8aaaca7d27cab657c3dcb15e1a3cb6  package-a66b056.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-a66b056-01
mkdir integrated-a66b056-source
tar -xf package-a66b056.tar -C integrated-a66b056-source
ln -s "$base/source-2a560be/lean/.lake" integrated-a66b056-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-a66b056-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-a66b056-01/build.stdout" 2> "$base/integrated-a66b056-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-a66b056-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-a66b056-01/audit.stdout" 2> "$base/integrated-a66b056-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-a66b056-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-a66b056-01/audit.stdout" > "$base/integrated-a66b056-01/check.stdout" 2> "$base/integrated-a66b056-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-a66b056-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-a66b056-01/* > "$base/integrated-a66b056-01/output-sha256.txt"
