#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo '8a8c496f6420a679672e852922b529fd91757e504ca56517f582a0da780b62f2  package-ef537f7.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-ef537f7-01
mkdir integrated-ef537f7-source
tar -xf package-ef537f7.tar -C integrated-ef537f7-source
ln -s "$base/source-2a560be/lean/.lake" integrated-ef537f7-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-ef537f7-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-ef537f7-01/build.stdout" 2> "$base/integrated-ef537f7-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-ef537f7-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-ef537f7-01/audit.stdout" 2> "$base/integrated-ef537f7-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-ef537f7-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-ef537f7-01/audit.stdout" > "$base/integrated-ef537f7-01/check.stdout" 2> "$base/integrated-ef537f7-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-ef537f7-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-ef537f7-01/* > "$base/integrated-ef537f7-01/output-sha256.txt"
