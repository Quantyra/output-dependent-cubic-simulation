﻿import SectorSimulation.SourceCrossAll
namespace SectorSimulation

theorem assemble_coordinate_cases {n : Nat} (P : Fin n → Fin n → Prop)
    (residual : Fin n → Prop) (pairs : List (Fin n × Fin n))
    (cover : ∀ i, residual i ∨ ∃ p ∈ pairs, i = p.1 ∨ i = p.2)
    (symm : ∀ i j, P i j → P j i) (diag : ∀ i, P i i)
    (rr : ∀ i j, residual i → residual j → P i j)
    (rp : ∀ i p, residual i → p ∈ pairs → P i p.1 ∧ P i p.2)
    (same : ∀ p ∈ pairs, P p.1 p.2)
    (cross : ∀ p q, p ∈ pairs → q ∈ pairs → p ≠ q →
      P p.1 q.1 ∧ P p.1 q.2 ∧ P p.2 q.1 ∧ P p.2 q.2) :
    ∀ i j, P i j := by
  intro i j
  rcases cover i with hi | ⟨p, hp, hi | hi⟩ <;>
  rcases cover j with hj | ⟨q, hq, hj | hj⟩
  · exact rr i j hi hj
  · subst j; exact (rp i q hi hq).1
  · subst j; exact (rp i q hi hq).2
  · subst i; exact symm j p.1 ((rp j p hj hp).1)
  · subst i; subst j
    by_cases h : p = q
    · subst q; exact diag _
    · exact (cross p q hp hq h).1
  · subst i; subst j
    by_cases h : p = q
    · subst q; exact same p hp
    · exact (cross p q hp hq h).2.1
  · subst i; exact symm j p.2 ((rp j p hj hp).2)
  · subst i; subst j
    by_cases h : p = q
    · subst q; exact symm _ _ (same p hp)
    · exact (cross p q hp hq h).2.2.1
  · subst i; subst j
    by_cases h : p = q
    · subst q; exact diag _
    · exact (cross p q hp hq h).2.2.2

#print axioms assemble_coordinate_cases
end SectorSimulation
