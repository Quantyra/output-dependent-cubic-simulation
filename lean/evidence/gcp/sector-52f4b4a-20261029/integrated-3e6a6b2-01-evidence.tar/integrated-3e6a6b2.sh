#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo '86cc5bc0b6af214f23302037aebceeb88fd4c8de449a0fb8cf9277ead247d81a  package-3e6a6b2.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-3e6a6b2-01
mkdir integrated-3e6a6b2-source
tar -xf package-3e6a6b2.tar -C integrated-3e6a6b2-source
ln -s "$base/source-2a560be/lean/.lake" integrated-3e6a6b2-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-3e6a6b2-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-3e6a6b2-01/build.stdout" 2> "$base/integrated-3e6a6b2-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-3e6a6b2-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-3e6a6b2-01/audit.stdout" 2> "$base/integrated-3e6a6b2-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-3e6a6b2-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-3e6a6b2-01/audit.stdout" > "$base/integrated-3e6a6b2-01/check.stdout" 2> "$base/integrated-3e6a6b2-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-3e6a6b2-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-3e6a6b2-01/* > "$base/integrated-3e6a6b2-01/output-sha256.txt"
