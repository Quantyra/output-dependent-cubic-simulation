#!/usr/bin/env bash
set -euo pipefail
run=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
src_cache=/home/dfredriksen_quantyra_org/quantyra-space-runs/space-20261007T093129Z-retry1/packages
tool=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin
mkdir "$run/execution-once"
cd "$run"
exec > >(tee -a runner.log) 2>&1
trap 'status=$?; printf "%s\n" "$status" > "$run/exit-code"' EXIT
printf '%s  %s\n' '3df95c49cef60aba3af06c94c6b73b3298ae8d943b572dfdcdda9e76ad78f9e2' "$run/source.tar" | sha256sum -c -
mkdir "$run/work"
tar -xf "$run/source.tar" -C "$run/work"
python3 - "$run/work/lean/lake-manifest.json" "$src_cache" <<'PY'
import json,sys,subprocess
from pathlib import Path
manifest=json.loads(Path(sys.argv[1]).read_text()); base=Path(sys.argv[2])
for package in manifest['packages']:
 p=base/package['name']
 rev=subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip()
 if rev!=package['rev']: raise SystemExit(f"dependency mismatch: {package['name']} {rev} != {package['rev']}")
 subprocess.run(['git','-C',str(p),'diff','--quiet','HEAD','--'],check=True)
 print(package['name'],rev,flush=True)
PY
needed=$(du -sb "$src_cache" | cut -f1)
available=$(df -PB1 "$run" | awk 'NR==2 {print $4}')
if [ "$needed" -gt 12000000000 ] || [ "$available" -lt $((needed+5000000000)) ]; then echo 'Insufficient bounded disk headroom'; exit 1; fi
mkdir -p "$run/work/lean/.lake"
cp -a --reflink=auto "$src_cache" "$run/work/lean/.lake/packages"
python3 - "$run/work/lean/.lake/packages" <<'PY'
from pathlib import Path
import sys
root=Path(sys.argv[1]).resolve()
for link in root.rglob('*'):
 if link.is_symlink() and not link.resolve().is_relative_to(root):
  raise SystemExit(f'external cache symlink prohibited: {link}')
PY
if pgrep -x lean >/dev/null || pgrep -x lake >/dev/null; then echo 'Shared Lean/Lake process active; refusing to launch'; exit 1; fi
export PATH="$tool:$PATH"
export MATHLIB_NO_CACHE_ON_UPDATE=1
lean --version | tee "$run/lean-version.txt"
grep -F 'version 4.30.0' "$run/lean-version.txt"
lake --version
sha256sum "$tool/lean" "$tool/lake" > "$run/toolchain-sha256.txt"
cd "$run/work/lean"
timeout 1800 lake build > "$run/build.stdout" 2> "$run/build.stderr"
timeout 900 lake env lean Audit.lean > "$run/audit.stdout" 2> "$run/audit.stderr"
for example in SourceExamples PivotExamples NativeJsonExamples ExactNativeExamples PhaseCompilerExamples ModeledRecognizerExamples; do
 timeout 900 lake env lean "$example.lean" > "$run/$example.stdout" 2> "$run/$example.stderr"
done
cd "$run/work"
timeout 900 python3 tools/check_python_lean_bridge.py > "$run/python-bridge.stdout" 2> "$run/python-bridge.stderr"
python3 tools/check_lean_audit.py "$run/audit.stdout" > "$run/audit-check.stdout" 2> "$run/audit-check.stderr"
sha256sum "$run"/build.stdout "$run"/build.stderr "$run"/audit.stdout "$run"/audit.stderr "$run"/audit-check.stdout "$run"/audit-check.stderr > "$run/output-sha256.txt"
echo 'BUILD_AUDIT_AND_EXAMPLES_PASSED'
