#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo 'dab5931e4729440605e0cfb0d6f5d0a883c46bd72834963af151a836abd4c150  package-6f75cfe.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-6f75cfe-01
mkdir integrated-6f75cfe-source
tar -xf package-6f75cfe.tar -C integrated-6f75cfe-source
ln -s "$base/work/lean/.lake" integrated-6f75cfe-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd integrated-6f75cfe-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-6f75cfe-01/build.stdout" 2> "$base/integrated-6f75cfe-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-6f75cfe-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-6f75cfe-01/audit.stdout" 2> "$base/integrated-6f75cfe-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-6f75cfe-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-6f75cfe-01/audit.stdout" > "$base/integrated-6f75cfe-01/check.stdout" 2> "$base/integrated-6f75cfe-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-6f75cfe-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-6f75cfe-01/* > "$base/integrated-6f75cfe-01/output-sha256.txt"
