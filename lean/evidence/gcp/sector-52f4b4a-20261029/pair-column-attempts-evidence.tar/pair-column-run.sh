set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo '7c5965bdbe4079246d43d95ccd4f2ce15f6fc4362d0935009a0aa6e052e6b697  PairColumnBridgeProbe.lean' | sha256sum -c
! pgrep -x lean
! pgrep -x lake
mkdir pair-column-bridge-01
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd "$base/integrated-7eea6ef-source/lean"
rc=0
timeout 900 lake env lean "$base/PairColumnBridgeProbe.lean" > "$base/pair-column-bridge-01/stdout" 2> "$base/pair-column-bridge-01/stderr" || rc=$?
echo "$rc" > "$base/pair-column-bridge-01/exit-code"
cat "$base/pair-column-bridge-01/exit-code" "$base/pair-column-bridge-01/stdout"
