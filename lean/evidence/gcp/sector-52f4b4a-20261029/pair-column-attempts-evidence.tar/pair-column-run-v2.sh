set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo 'ab16b886d3d7ff73cc82860533d521f8aabedbe679f5148d7624921f1f31c474  PairColumnBridgeProbe-v2.lean' | sha256sum -c
! pgrep -x lean
! pgrep -x lake
mkdir pair-column-bridge-02
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd "$base/integrated-7eea6ef-source/lean"
rc=0
timeout 900 lake env lean "$base/PairColumnBridgeProbe-v2.lean" > "$base/pair-column-bridge-02/stdout" 2> "$base/pair-column-bridge-02/stderr" || rc=$?
echo "$rc" > "$base/pair-column-bridge-02/exit-code"
cat "$base/pair-column-bridge-02/exit-code" "$base/pair-column-bridge-02/stdout"
