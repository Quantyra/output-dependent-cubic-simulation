#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo '3567efdfd087298030c1ee4de3c5f50cd5888b0a9cabbff929945e8e9b63088c  package-ba0e144.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-ba0e144-01
mkdir integrated-ba0e144-source
tar -xf package-ba0e144.tar -C integrated-ba0e144-source
ln -s "$base/work/lean/.lake" integrated-ba0e144-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd integrated-ba0e144-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-ba0e144-01/build.stdout" 2> "$base/integrated-ba0e144-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-ba0e144-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-ba0e144-01/audit.stdout" 2> "$base/integrated-ba0e144-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-ba0e144-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-ba0e144-01/audit.stdout" > "$base/integrated-ba0e144-01/check.stdout" 2> "$base/integrated-ba0e144-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-ba0e144-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-ba0e144-01/* > "$base/integrated-ba0e144-01/output-sha256.txt"
