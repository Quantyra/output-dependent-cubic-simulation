set -eu
base=/home/dfredriksen_quantyra_org/quantyra-sector-runs/source-52f4b4a-20261029
cd "$base"
echo '43df51de8ed36fec2a16dd3bdb52029abe96fb71615ec9bbe170c1722f4de6ff  PairColumnProgramProbe.lean' | sha256sum -c
! pgrep -x lean
! pgrep -x lake
mkdir pair-column-program-01
export PATH=/home/dfredriksen_quantyra_org/quantyra-space-tools/lean-4.30.0-linux/bin:$PATH
cd "$base/integrated-e4b64c3-source/lean"
rc=0
timeout 900 lake env lean "$base/PairColumnProgramProbe.lean" > "$base/pair-column-program-01/stdout" 2> "$base/pair-column-program-01/stderr" || rc=$?
echo "$rc" > "$base/pair-column-program-01/exit-code"
cat "$base/pair-column-program-01/exit-code" "$base/pair-column-program-01/stdout"
