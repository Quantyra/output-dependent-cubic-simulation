#!/usr/bin/env bash
set -eu
base=/home/dfredriksen_quantyra_org/sector-certification
cd "$base"
echo '7e026b5e6148bbd9fa6787ae639cb8fe2d9d4eb9b63555fa7d3f6edaf67f869a  package-47372ea.tar' | sha256sum -c
if pgrep -x lean; then exit 75; fi
if pgrep -x lake; then exit 75; fi
mkdir integrated-47372ea-01
mkdir integrated-47372ea-source
tar -xf package-47372ea.tar -C integrated-47372ea-source
ln -s "$base/source-2a560be/lean/.lake" integrated-47372ea-source/lean/.lake
export PATH=/home/dfredriksen_quantyra_org/sector-certification/tools/lean-4.30.0-linux/bin:$PATH
cd integrated-47372ea-source/lean
rc=0
timeout 1800 lake build > "$base/integrated-47372ea-01/build.stdout" 2> "$base/integrated-47372ea-01/build.stderr" || rc=$?
echo "$rc" > "$base/integrated-47372ea-01/build.exit-code"
if [ "$rc" -eq 0 ]; then
  rc=0
  timeout 900 lake env lean Audit.lean > "$base/integrated-47372ea-01/audit.stdout" 2> "$base/integrated-47372ea-01/audit.stderr" || rc=$?
  echo "$rc" > "$base/integrated-47372ea-01/audit.exit-code"
  if [ "$rc" -eq 0 ]; then
    rc=0
    python3 ../tools/check_lean_audit.py "$base/integrated-47372ea-01/audit.stdout" > "$base/integrated-47372ea-01/check.stdout" 2> "$base/integrated-47372ea-01/check.stderr" || rc=$?
    echo "$rc" > "$base/integrated-47372ea-01/check.exit-code"
  fi
fi
sha256sum "$base"/integrated-47372ea-01/* > "$base/integrated-47372ea-01/output-sha256.txt"
