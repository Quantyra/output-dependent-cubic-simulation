#!/usr/bin/env bash
set -eu
root=/home/dfredriksen_quantyra_org/sector-certification
archive_sha=10bbc44bd20bb5e527b0d2f57130607948c534177e48cc23efa5630e7879fc99
cd "$root"
printf '%s  package-a335d89.tar\n' "$archive_sha" | sha256sum -c -
printf '%s\n' 'a335d892848adba8b1ceb5c57ec16484ca58d522' > "$root/integrated-a335d89-source-commit.txt"
mkdir -p source-a335d89
tar -xf package-a335d89.tar -C source-a335d89
cd source-a335d89/lean
mkdir -p .lake
if [ ! -e .lake/packages ]; then
  ln -s "$root/source-2a560be/lean/.lake/packages" .lake/packages
fi
export PATH="$root/tools/lean-4.30.0-linux/bin:$PATH"
set +e
timeout 1200 lake build > "$root/integrated-a335d89-build.stdout" 2> "$root/integrated-a335d89-build.stderr"
rc=$?
printf '%s\n' "$rc" > "$root/integrated-a335d89-build.exit-code"
cat "$root/integrated-a335d89-build.stdout"
cat "$root/integrated-a335d89-build.stderr" >&2
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
timeout 1200 lake env lean Audit.lean > "$root/integrated-a335d89-audit.stdout" 2> "$root/integrated-a335d89-audit.stderr"
rc=$?
printf '%s\n' "$rc" > "$root/integrated-a335d89-audit.exit-code"
if [ "$rc" -ne 0 ]; then
  cat "$root/integrated-a335d89-audit.stdout"
  cat "$root/integrated-a335d89-audit.stderr" >&2
  exit "$rc"
fi
python3 ../tools/check_lean_audit.py "$root/integrated-a335d89-audit.stdout" > "$root/integrated-a335d89-checker.stdout" 2> "$root/integrated-a335d89-checker.stderr"
rc=$?
printf '%s\n' "$rc" > "$root/integrated-a335d89-checker.exit-code"
cat "$root/integrated-a335d89-checker.stdout"
cat "$root/integrated-a335d89-checker.stderr" >&2
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
python3 ../tools/check_claims.py > "$root/integrated-a335d89-claims.stdout" 2> "$root/integrated-a335d89-claims.stderr"
rc=$?
printf '%s\n' "$rc" > "$root/integrated-a335d89-claims.exit-code"
cat "$root/integrated-a335d89-claims.stdout"
cat "$root/integrated-a335d89-claims.stderr" >&2
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
sha256sum "$root"/integrated-a335d89-* > "$root/integrated-a335d89-artifact-hashes.txt"